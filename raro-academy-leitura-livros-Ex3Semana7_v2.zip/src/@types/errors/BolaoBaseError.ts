export interface BolaoBaseError extends Error {
  name: string;
}