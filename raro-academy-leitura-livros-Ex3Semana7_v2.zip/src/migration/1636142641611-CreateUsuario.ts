import {MigrationInterface, QueryRunner} from "typeorm";

export class CreateUsuario1636142641611 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
