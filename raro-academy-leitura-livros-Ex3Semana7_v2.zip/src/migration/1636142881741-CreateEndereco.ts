import {MigrationInterface, QueryRunner} from "typeorm";

export class CreateEndereco1636142881741 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
