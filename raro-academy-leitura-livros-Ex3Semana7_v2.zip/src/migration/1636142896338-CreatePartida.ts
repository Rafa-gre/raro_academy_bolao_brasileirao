import {MigrationInterface, QueryRunner} from "typeorm";

export class CreatePartida1636142896338 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
